﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex._01.Models
{
    public class RiderDP
    {
        public static List <Rider> riderList = new List <Rider> ();
    }
}
